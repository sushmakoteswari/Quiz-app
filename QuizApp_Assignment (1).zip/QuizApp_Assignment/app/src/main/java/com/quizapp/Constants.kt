package com.quizapp

import com.quizapp.R
import com.quizapp.Question

object Constants {

    // TODO (STEP 1: Create a constant variables which we required in the result screen.)
    // START
    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String = "total_questions"
    const val CORRECT_ANSWERS: String = "correct_answers"
    // END

    fun getQuestions(): ArrayList<Question> {
        val questionsList = ArrayList<Question>()

        // 1
        val que1=Question(1, "Where is leaning tower of pisa located?",
            R.drawable.img,"Pisa",
            "Peru",
            "Italy",
            "Mangolia",
            1)

        questionsList.add(que1)

        // 2
        val que2=Question(2, "What is present capital of this country?",
            R.drawable.img_1,"Palanan",
            "Baguio ",
            "Quezon",
            "Manila",
            4)

        questionsList.add(que2)

        // 3
        val que3=Question(3, "What is Capital of New Zealeand",
            R.drawable.img_2,"Auckland",
            "Willington",
            "Old Russell",
            "Polynesia",
            2)

        questionsList.add(que3)

        // 4
        val que4=Question(4, "Where is this Bridge Located",
        R.drawable.img_3,"California",
        "San francisco",
        "Columbia",
            "Colorado",
        1)

        questionsList.add(que4)

        // 5
        val que5=Question(5, "What is Capital of this Country?",
            R.drawable.img_4,"Bhagdad",
            "Karachi",
            "Kabul",
            "Almaty",
            1)

        questionsList.add(que5)

        return questionsList
    }
}